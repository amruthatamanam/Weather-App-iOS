//
//  Protocols.swift
//  Weather
//
//  Created by Amrutha on 05/15/23.
//

import Foundation
