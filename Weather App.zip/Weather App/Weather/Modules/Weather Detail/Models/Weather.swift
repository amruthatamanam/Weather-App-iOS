//
//	Weather.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation

struct Weather : Codable {

	let description : String?
	let icon : String?
	let id : Int?
	let main : String?


}
