//
//	Wind.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation

struct Wind : Codable {

	let deg : Float?
	let speed : Float?


}