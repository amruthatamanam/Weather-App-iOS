//
//	Sy.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation

struct Sy : Codable {

	let country : String?
	let id : Int?
	let message : Float?
	let sunrise : Int?
	let sunset : Int?
	let type : Int?


}