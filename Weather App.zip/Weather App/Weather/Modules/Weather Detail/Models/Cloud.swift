//
//	Cloud.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation

struct Cloud : Codable {

	let all : Int?


}