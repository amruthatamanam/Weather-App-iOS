//
//  SearchResultModel.swift
//  Weather
//
//  Created by Amrutha on 05/15/23.
//

import Foundation

struct SearchResultModel: Codable {
    let name: String?
    let lat: Double?
    let lon: Double?
    let country: String?
    let state: String?
}
